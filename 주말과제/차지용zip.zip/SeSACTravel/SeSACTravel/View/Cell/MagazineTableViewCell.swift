//
//  TravelTableViewCell.swift
//  SeSACTravel
//
//  Created by 차지용 on 7/11/25.
//

import UIKit

class MagazineTableViewCell: UITableViewCell {

    @IBOutlet var potoImage: UIImageView!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var subtitleLabel: UILabel!
    @IBOutlet var dateLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
