//
//  CellProtocol.swift
//  TravelTalk
//
//  Created by 차지용 on 7/22/25.
//

import Foundation

protocol CellProtocol {
    func configureUI()
}
