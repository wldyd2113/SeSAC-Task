//
//  APIKey.swift
//  NaverSearch
//
//  Created by 차지용 on 7/29/25.
//

import Foundation

struct APIKey {
    private init() { }
    static let naverID = "skLvqKWpYQN5oOWjEK9g"
    static let naverSecret = "o8KK6vOXf6"
}
