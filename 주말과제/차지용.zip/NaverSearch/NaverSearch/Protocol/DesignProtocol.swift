//
//  DesignProtocol.swift
//  NaverSearch
//
//  Created by 차지용 on 7/25/25.
//

import UIKit

protocol DesignProtocol {
    func configure()
    func configureLayout()
}
