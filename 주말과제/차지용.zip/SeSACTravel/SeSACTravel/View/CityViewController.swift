//
//  CityViewController.swift
//  SeSACTravel
//
//  Created by 차지용 on 7/16/25.
//

import UIKit

class CityViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    
    let cityList = CityInfo().city
    
    @IBOutlet var searchTextField: UITextField!
    @IBOutlet var segment: UISegmentedControl!
    @IBOutlet var cityTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cityTable.delegate = self
        cityTable.dataSource = self
        let xib = UINib(nibName: "CityTableViewCell", bundle: nil)
        cityTable.register(xib, forCellReuseIdentifier: "CityTableViewCell")
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var count = 0
        for city in cityList {
            if segment.selectedSegmentIndex == 0 {
                count += 1
            }
            else if segment.selectedSegmentIndex == 1 && city.domestic_travel == true {
                count += 1
            }
            else if segment.selectedSegmentIndex == 2 && city.domestic_travel == false {
                count += 1
            }
        }
        return count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CityTableViewCell", for: indexPath) as! CityTableViewCell
        let cityIndexPath = cityList[indexPath.row]
        let selected = segment.selectedSegmentIndex
        if selected == 0 {
            cell.configureCityCell(cityIndexPath: cityIndexPath)
            print(cityList[indexPath.row])
        }
        else if selected == 1 && cityIndexPath.domestic_travel == true {
            
            cell.configureCityCell(cityIndexPath: cityIndexPath)
            
        }
        else if selected == 2 && cityIndexPath.domestic_travel == false {
            cell.configureCityCell(cityIndexPath: cityIndexPath)
            print(cityList)
            
        }
        
        
        //        switch segment.selectedSegmentIndex {
        //        case 0:
        //            cell.configureCityCell(cityIndexPath: cityIndexPath)
        //        case 1:
        //            if cityIndexPath.domestic_travel == true {
        //                cell.configureCityCell(cityIndexPath: cityIndexPath)
        //            }
        //        case 2:
        //            if cityIndexPath.domestic_travel == false {
        //                cell.configureCityCell(cityIndexPath: cityIndexPath)
        //            }
        //
        //        default:
        //            cell.configureCityCell(cityIndexPath: cityIndexPath)
        //        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cityData = cityList[indexPath.row]
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let vc = sb.instantiateViewController(withIdentifier: "CityDetailViewController") as! CityDetailViewController
        vc.listData = cityData
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    @IBAction func segmentChanged(_ sender: UISegmentedControl) {
        cityTable.reloadData()
    }
    
    
    @IBAction func serachText(_ sender: UITextField) {
    }
}
