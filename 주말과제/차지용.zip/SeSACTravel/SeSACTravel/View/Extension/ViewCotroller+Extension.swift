//
//  ViewCotroller+Extension.swift
//  SeSACTravel
//
//  Created by 차지용 on 7/14/25.
//

import Foundation
import UIKit
extension UIViewController {
    func configureBackground() {
        view.backgroundColor = .white
    }
}
