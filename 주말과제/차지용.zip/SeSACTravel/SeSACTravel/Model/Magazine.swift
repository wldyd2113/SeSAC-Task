//
//  Magazine.swift
//  SeSACTravel
//
//  Created by 차지용 on 7/11/25.
//

import Foundation
struct Magazine {
    let title: String
    let subtitle: String
    let photo_image: String
    let date: String
    let link: String
}
