//
//  Travel.swift
//  SeSACTravel
//
//  Created by 차지용 on 7/11/25.
//


import Foundation

struct Travel {
    
    var title: String?
    var description: String?
    var travel_image: String?
    var grade: Double?
    var save: Int?
    var like: Bool?
    var ad: Bool?
}

