//
//  City.swift
//  SeSACTravel
//
//  Created by 차지용 on 7/15/25.
//

import Foundation

struct City {
    let city_name: String?
    let city_english_name: String?
    let city_explain: String?
    let city_image: String?
    let domestic_travel: Bool?
}
