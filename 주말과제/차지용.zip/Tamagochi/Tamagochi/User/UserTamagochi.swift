//
//  Tamagochi.swift
//  Tamagochi
//
//  Created by 차지용 on 8/24/25.
//

import Foundation

enum UserTamagochi: String {
    case rice = "rice"
    case water = "water"
    case nickName = "nickName"
    case level = "level"
    case selectedTamagochi = "selectedTamagochi"
}
