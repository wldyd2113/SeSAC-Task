//
//  Tamagochi.swift
//  Tamagochi
//
//  Created by 차지용 on 8/24/25.
//

import Foundation

struct Tamagochi {
    let name: String
    let image: String
}
