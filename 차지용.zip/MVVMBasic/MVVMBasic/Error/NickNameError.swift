//
//  NickNameError.swift
//  MVVMBasic
//
//  Created by 차지용 on 8/9/25.
//

import Foundation
enum NickNameError: Error {
    case emptyError
    case particularError
    case isStringError
    case outOfNicknameError

    
}
