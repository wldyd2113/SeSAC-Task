//
//  ViewController.swift
//  RxSampleProject
//
//  Created by 차지용 on 8/19/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
    }


}

