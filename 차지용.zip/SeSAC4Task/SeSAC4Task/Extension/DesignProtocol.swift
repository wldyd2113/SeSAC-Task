//
//  DesignProtocol.swift
//  SeSAC4Task
//
//  Created by 차지용 on 7/23/25.
//

import Foundation

protocol DesignProtocol {
    func configure()
    func configureLayout()
}
